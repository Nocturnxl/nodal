import type { ProviderConfig } from '@shared/types';
import type { ProviderAdapter } from './adapter';
import { createOpenAiCompatibleAdapter } from './openaiCompatible';
import { veniceExtension } from './venice';

const generic = createOpenAiCompatibleAdapter();
const venice = createOpenAiCompatibleAdapter(veniceExtension);

/** Adapter lookup. Later kinds ('anthropic', 'google') get their own adapter here. */
export function adapterFor(config: Pick<ProviderConfig, 'kind' | 'preset'>): ProviderAdapter {
  if (config.preset === 'venice') return venice;
  return generic;
}
